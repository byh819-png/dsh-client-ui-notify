# install.ps1 - install dsh-client-ui-notify into the local dsh web profile.
# Idempotent: safe to re-run. Touches only two locations:
#   1) $DSH_HOME\profiles\node_modules\@deepseek-ai\dsh-client-ui-notify\
#   2) $DSH_HOME\profiles\web\cordis.patch.yml (appends the loader row if missing)
# Usage:  powershell -ExecutionPolicy Bypass -File .\install.ps1

$ErrorActionPreference = 'Stop'

# Locate DSH_HOME
if ($env:DSH_HOME -and (Test-Path $env:DSH_HOME)) {
  $dshHome = $env:DSH_HOME
} else {
  $dshHome = Join-Path $HOME '.dsh'
}
if (-not (Test-Path $dshHome)) {
  throw "DSH_HOME not found: $dshHome. Run dsh once (e.g. 'dsh web') or set the DSH_HOME environment variable."
}

# 1) Copy the plugin package into the installation closure fallback directory
$pkgRel = Join-Path 'profiles' (Join-Path 'node_modules' (Join-Path '@deepseek-ai' 'dsh-client-ui-notify'))
$pkgDir = Join-Path $dshHome $pkgRel
$srcDir = Join-Path $PSScriptRoot 'package'
if (-not (Test-Path $srcDir)) { throw "package directory not found: $srcDir (extract the whole archive first)" }

New-Item -ItemType Directory -Path (Split-Path $pkgDir) -Force | Out-Null
if (Test-Path $pkgDir) {
  Write-Host "[1/3] Plugin directory already exists; overwriting: $pkgDir"
  Remove-Item $pkgDir -Recurse -Force
}
Copy-Item -Recurse $srcDir $pkgDir
Write-Host "[1/3] Plugin copied to $pkgDir"

# 2) Append the loader row to the web profile user layer
$profileDir = Join-Path $dshHome (Join-Path 'profiles' 'web')
if (-not (Test-Path $profileDir)) { throw "web profile not found: $profileDir" }
$patchFile = Join-Path $profileDir 'cordis.patch.yml'
if (-not (Test-Path $patchFile)) {
  Set-Content -Path $patchFile -Value '[]' -Encoding UTF8
}
$patch = Get-Content $patchFile -Raw
if ($patch -match 'dsh-client-ui-notify') {
  Write-Host '[2/3] cordis.patch.yml already contains the plugin row; skipping'
} else {
  $block = @"

# Sound-alert plugin: rings on answer-complete and authorization-needed edges.
- insert:
    - id: ui-notify
      name: '@deepseek-ai/dsh-client-ui-notify'
"@
  Add-Content -Path $patchFile -Value $block -Encoding UTF8
  Write-Host "[2/3] Appended the plugin row to $patchFile"
}

# 3) Done
Write-Host '[3/3] Installation complete. Restart the dsh web server, refresh the browser,'
Write-Host '      then open Settings > General to find the Sound alerts row.'
