import type { IncomingMessage, ServerResponse } from 'node:http';
/**
 * Absolute directory holding user-picked audio files.
 * @returns the per-id file directory under the Harness home.
 */
export declare function audioStorageDir(): string;
/**
 * The route handler: trust fence first, then id+extension parsing, then the
 * method dispatch. Any parse or trust failure is a plain 403/404 — no user
 * content reaches the filesystem without a valid id.
 * @param req - the incoming request.
 * @param res - the response to write.
 */
export declare function handleAudioRequest(req: IncomingMessage, res: ServerResponse): Promise<void>;
//# sourceMappingURL=audio-store.d.ts.map