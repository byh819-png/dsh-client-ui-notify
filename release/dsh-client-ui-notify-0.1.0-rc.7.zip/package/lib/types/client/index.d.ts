import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type NotifySettings } from '../notify-settings.ts';
import { type NotifyKey } from './locales.ts';
import { NotifyRuntime } from './notify-runtime.ts';
export type { NotifyRowComponentProps, NotifyRowInjected } from './NotifyRow.tsx';
export type { NotifyRowState } from './settings-store.ts';
export type { NotifyKey } from './locales.ts';
export type { NotifyMethod, NotifySettings } from '../notify-settings.ts';
export { AUDIO_EXTENSION_MEDIA_TYPES, AUDIO_ID_PATTERN, AUDIO_URL_PREFIX, MAX_AUDIO_BYTES, audioExtensionOfMediaType, audioMediaTypeOfExtension, } from '../notify-settings.ts';
export { NotifyRuntime, type SessionObservation } from './notify-runtime.ts';
export { createBrowserEngine, dispatch, type PlaybackEngine } from './sounds.ts';
export { createNotifyRowStore } from './settings-store.ts';
export { NotifyRow } from './NotifyRow.tsx';
/** Namespace owning this feature's settings-row copy. */
export declare const SETTINGS_NS = "settings.notify";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The notification settings row's copy. */
        'settings.notify': NotifyKey;
    }
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        notify: NotifyRuntime;
    }
    interface Events {
        /**
         * The accepted notification settings changed (user write, scope adoption,
         * or reconnect re-read).
         * @param config - the full accepted section (immutable snapshot).
         * @mode emit
         */
        'notify/config'(config: NotifySettings): void;
    }
}
/**
 * Required services: settings transport, the session list observation source,
 * plus slots/locale for the preference row. `remote` carries the forwarded
 * settings invalidation that `bindSettingsScope` subscribes to on this context.
 */
export declare const inject: string[];
/**
 * Client plugin body: provide the notification runtime and register the
 * feature-owned preference row into the General section's item slot.
 * @param ctx - client cordis context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map