/** `settings.notify` namespace dictionaries (the notification row's copy). */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'notify.title': string;
    'notify.enabled': string;
    'notify.onAnswerComplete': string;
    'notify.onAuthRequired': string;
    'notify.method': string;
    'notify.method.builtin': string;
    'notify.method.tts': string;
    'notify.method.custom': string;
    'notify.ttsText': string;
    'notify.ttsTextHint': string;
    'notify.customAudioUrl': string;
    'notify.customHint': string;
    'notify.pickFile': string;
    'notify.preview': string;
    'notify.uploaded': string;
    'notify.fileTooLarge': string;
    'notify.fileTypeUnsupported': string;
    'notify.uploadFailed': string;
};
/** The settings.notify namespace key union. */
export type NotifyKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'notify.title': string;
    'notify.enabled': string;
    'notify.onAnswerComplete': string;
    'notify.onAuthRequired': string;
    'notify.method': string;
    'notify.method.builtin': string;
    'notify.method.tts': string;
    'notify.method.custom': string;
    'notify.ttsText': string;
    'notify.ttsTextHint': string;
    'notify.customAudioUrl': string;
    'notify.customHint': string;
    'notify.pickFile': string;
    'notify.preview': string;
    'notify.uploaded': string;
    'notify.fileTooLarge': string;
    'notify.fileTypeUnsupported': string;
    'notify.uploadFailed': string;
};
//# sourceMappingURL=locales.d.ts.map